# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html


# useful for handling different item types with a single interface
from itemadapter import ItemAdapter
import csv

class TaobaoPipeline:
    def open_spider(self,spider):
        with open(file="淘宝数码产品名单.csv",mode="w",encoding="UTF-8",newline="")as f:
            write = csv.DictWriter(f,fieldnames=["positions","price","sales","name","title_name"])
            write.writeheader()
    def process_item(self, item, spider):
        # print(item)
        with open(file="淘宝数码产品名单.csv", mode="a", encoding="UTF-8", newline="") as f:
            write = csv.DictWriter(f, fieldnames=["positions", "price", "sales", "name", "title_name"])
            """csv写入数据是writerow写入字典类型的数据"""
            write.writerow(item)
        return item