# Scrapy settings for taobao project
#
# For simplicity, this file contains only settings considered important or
# commonly used. You can find more settings consulting the documentation:
#
#     https://docs.scrapy.org/en/latest/topics/settings.html
#     https://docs.scrapy.org/en/latest/topics/downloader-middleware.html
#     https://docs.scrapy.org/en/latest/topics/spider-middleware.html

BOT_NAME = 'taobao'

SPIDER_MODULES = ['taobao.spiders']
NEWSPIDER_MODULE = 'taobao.spiders'
LOG_LEVEL = "WARNING"

# Crawl responsibly by identifying yourself (and your website) on the user-agent
#USER_AGENT = 'taobao (+http://www.yourdomain.com)'

# Obey robots.txt rules
ROBOTSTXT_OBEY = False

# Configure maximum concurrent requests performed by Scrapy (default: 16)
#CONCURRENT_REQUESTS = 32

# Configure a delay for requests for the same website (default: 0)
# See https://docs.scrapy.org/en/latest/topics/settings.html#download-delay
# See also autothrottle settings and docs
#DOWNLOAD_DELAY = 3
# The download delay setting will honor only one of:
#CONCURRENT_REQUESTS_PER_DOMAIN = 16
#CONCURRENT_REQUESTS_PER_IP = 16

# Disable cookies (enabled by default)
COOKIES_ENABLED = False

# Disable Telnet Console (enabled by default)
# TELNETCONSOLE_ENABLED = False

# Override the default request headers:
DEFAULT_REQUEST_HEADERS = {
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'Accept-Language': 'en',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36',
    'cookie':'thw=cn; cna=h70sGeVnLwACAXzqBiQU/XUs; tracknick=%5Cu964C%5Cu5F62%5Cu540C%5Cu964C%5Cu8DEF; miid=6592174521501002644; t=80dec2d638da4fb705313239f72b0f46; sgcookie=E100ivh28ZVynb0sFG4E%2FqI0FCeOOFkxA2i801%2B%2FlE2oU%2BlSGVcZO328oyX7hrAM61AFE0F5mCBL7ZDe24LkEtbjR%2FCz1QZWYsxsPm098aLGngM%3D; uc3=lg2=W5iHLLyFOGW7aA%3D%3D&id2=UNJV3avEwlVaGQ%3D%3D&nk2=p3hnO4PGztOqmQ%3D%3D&vt3=F8dCv4tAaNn13oKYqJk%3D; lgc=%5Cu964C%5Cu5F62%5Cu540C%5Cu964C%5Cu8DEF; uc4=id4=0%40UgXSqZp2CHA9YsFrxlM8BkaeQH6b&nk4=0%40pU794NRVl42UYuB6kzOP917CxCV0; _cc_=URm48syIZQ%3D%3D; enc=qD1SaJ4ZeK9dqms%2BDk%2FJpj2RpAzhJ40XaxLdm%2BZh1GJPP3JZCXr8zOecfx9MrlokVjlXfCjiUIhvKIQob5hG7Q%3D%3D; tk_trace=oTRxOWSBNwn9dPyorMJE%2FoPdY8zMG1aAN%2F0TkjYGZjkj6rrK3kv4LgxGhtlxvv5DK7siwhr9c%2BstdFdCVk5KERc8D0HFQc5jBvKF%2By4dZOjN3E3VwTBhtLWaHmQqs3nGsZH0LGPgdP%2BUeaoA%2F7CsjbLBhDTnLSdxF9FTwj9BQZXhceA19QEbWZ3gPTXTmDxqDF3y0x5aKYZmLD7AVrTKKkU0HY3OXiEQyiWFOs%2FV%2FwunQTElxJ%2F%2BpfZZrcDnWNsFXEnxkRctPNSA2ubE0oV96qyQumV1vE2jOHgHm%2BzKT1VkCMmQgnuW4ccP7EjNo5xxTp0c1YcFoDFeNX3nxuD%2F1Sa7DbGVyKlBWnKUadxg%2BrAYkZYAHT7SZeWsh%2F5xjYN4eD43HUr28yzEF%2FY%3D; mt=ci=-1_0; _tb_token_=fbe8ebeaed30d; _m_h5_tk=676e09020ccfe85c6085be4476da75cf_1667318293699; _m_h5_tk_enc=a0b292809d530cce58bbac77d751da40; uc1=cookie14=UoeyCUIkC30fwQ%3D%3D; xlly_s=1; alitrackid=www.taobao.com; lastalitrackid=www.taobao.com; cookie2=115f3d67d423620d080dd26f2e1c3be1; _samesite_flag_=true; JSESSIONID=F0200BA241B19D7EA1689B82B499CD23; isg=BG1tOHbZ8q2G4Zbo0lk88sC1fAnnyqGcLxFb-69yqYRzJo3YdxqxbLv0EPrAvblU; l=eBTHqCIgTULyXf8CBOfanurza77OSIRYYuPzaNbMiOCP935B5jyFW6rbJI86C3GVh6D9R3z1UrspBeYBq3xonxv92j-la_kmn; tfstk=cSUcBWi8poojXm7TF-gfRfO1HeQdwTRqhDnzz_DYw2tHvH1mO3-eBpJjU962f'
}

# Enable or disable spider middlewares
# See https://docs.scrapy.org/en/latest/topics/spider-middleware.html
#SPIDER_MIDDLEWARES = {
#    'taobao.middlewares.TaobaoSpiderMiddleware': 543,
#}

# Enable or disable downloader middlewares
# See https://docs.scrapy.org/en/latest/topics/downloader-middleware.html
#DOWNLOADER_MIDDLEWARES = {
#    'taobao.middlewares.TaobaoDownloaderMiddleware': 543,
#}

# Enable or disable extensions
# See https://docs.scrapy.org/en/latest/topics/extensions.html
#EXTENSIONS = {
#    'scrapy.extensions.telnet.TelnetConsole': None,
#}

# Configure item pipelines
# See https://docs.scrapy.org/en/latest/topics/item-pipeline.html
ITEM_PIPELINES = {
   'taobao.pipelines.TaobaoPipeline': 300,
}

# Enable and configure the AutoThrottle extension (disabled by default)
# See https://docs.scrapy.org/en/latest/topics/autothrottle.html
#AUTOTHROTTLE_ENABLED = True
# The initial download delay
#AUTOTHROTTLE_START_DELAY = 5
# The maximum download delay to be set in case of high latencies
#AUTOTHROTTLE_MAX_DELAY = 60
# The average number of requests Scrapy should be sending in parallel to
# each remote server
#AUTOTHROTTLE_TARGET_CONCURRENCY = 1.0
# Enable showing throttling stats for every response received:
#AUTOTHROTTLE_DEBUG = False

# Enable and configure HTTP caching (disabled by default)
# See https://docs.scrapy.org/en/latest/topics/downloader-middleware.html#httpcache-middleware-settings
#HTTPCACHE_ENABLED = True
#HTTPCACHE_EXPIRATION_SECS = 0
#HTTPCACHE_DIR = 'httpcache'
#HTTPCACHE_IGNORE_HTTP_CODES = []
#HTTPCACHE_STORAGE = 'scrapy.extensions.httpcache.FilesystemCacheStorage'
