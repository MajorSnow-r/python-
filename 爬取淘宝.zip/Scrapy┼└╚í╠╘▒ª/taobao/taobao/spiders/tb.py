import re

import scrapy
from ..items import TaobaoItem


class TbSpider(scrapy.Spider):
    name = 'tb'
    allowed_domains = ['s.taobao.com']
    url = "https://s.taobao.com/search?spm=a21bo.jianhua.201867-main.14.5af911d9JQocMH&q=%E6%95%B0%E7%A0%81&bcoffset=4&p4ppushleft=2%2C48&ntoffset=4&s={}"
    start_urls = [url.format(0)]
    # 计数器
    count = 0
    jishu = 0

    def parse(self, response):
        """直接用正则表达式去获取信息 """
        # 获取到包含所有数据内容的范围
        goods_match = re.search(r'g_page_config = (.*?)}};', response.text)
        a = goods_match.group(1)
        # 位置
        position = re.findall(r'"item_loc":"(.*?)","',a)
        # 标题
        data = re.findall(',"title":"(.*?)","raw_title',a,re.S)
        # 价格
        price = re.findall('"view_price":"(.*?)",',a,re.S)
        # 销量
        sales = re.findall('"view_sales":"(.*?)","',a,re.S)
        # 店铺名称
        name = re.findall('"nick":"(.*?)","',a,re.S)
        zip_data = zip(position,data,price,sales,name)
        for i in zip_data:
            item = TaobaoItem()
            item["positions"] = i[0]
            item["price"] = i[2]
            item["sales"] = i[3]
            item["name"] = i[4]
            """利用re.split同时分割两个没有用的字符串"""
            title = re.split(r"\\u003cspan class\\u003dH\\u003e|\\u003c/span\\u003e",i[1])
            item["title_name"] = "".join(title)
            yield item
        if self.count < 836:
            url_zhen = self.url.format(self.count)
            yield scrapy.Request(url=url_zhen)
            self.count += 44
            print(f"正在爬取{self.jishu}页")
            self.jishu += 1


