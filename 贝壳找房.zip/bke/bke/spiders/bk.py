import scrapy
import re
"""将items引入导爬虫程序,先将scrapy文件设置成根目录,然后导入这个items进行使用"""
from bke.items import BkeItem

class BkSpider(scrapy.Spider):
    name = 'bk'
    allowed_domains = ['hz.zu.ke.com']
    """翻页处理"""
    url = 'https://hz.zu.ke.com/zufang/pg{}/#contentList'
    start_urls = [url.format(1)]
    # 定义一个计数器
    count = 2
    def parse(self, response,**kwargs):
        # print(response.text)

        # 获取所有的标题
        title = re.findall('<a class="twoline" target=".*?" href=".*?\n(.*?)</a>.*?',response.text,re.S)

        # 获取所有的 区域 街区 小区
        """finditer是可以通过(?P<name>)的方法进行取值的,返回的是迭代器,要循环遍历出来,然后用groupdict()在字典的值"""
        dic = re.finditer('<a target="_blank" href=".*?">(?P<region>.*?)</a>-<a href=".*?" target="_blank">(?P<block>.*?)</a>-<a title="(?P<community>.*?)"',response.text,re.S)

        # 获取所有的房间面积 朝向 户型 租金 时间
        dicss = re.finditer('</a>[\s]*<i>/</i>[\s]*(?P<area>.*?)[\s]*<i>/</i>(?P<toward>.*?)[\s]*<i>/</i>[\s]*(?P<type>.*?)[\s]*<span class=".*?">.*?<span class=".*? oneline">(?P<time>.*?)</span>.*?.*?<span class=".*?"><em>(?P<rent>.*?)</em>(?P<danw>.*?)</span>[\s]*</div>',response.text,re.S)
        # 测试正则代码
        # dics = re.findall('</a>[\s]*<i>/</i>[\s]*(.*?)[\s]*<i>/</i>(.*?)[\s]*<i>/</i>[\s]*(.*?)[\s]*<span class=".*?">.*?<span class=".*? oneline">(.*?)</span>.*?.*?<span class=".*?"><em>(.*?)</em>(.*?)</span>[\s]*</div>',response.text,re.S)
        """将列表都打包到一起然后进行遍历"""
        datas = zip(title,dic,dicss)
        # 实例化一个item对象
        itme = BkeItem()
        for i in datas:

            # 利用groupdict将finditer返回的字典的键值都获取出来
            a = i[1].groupdict()
            c = i[2].groupdict()
            # 将数据封装起来
            itme['area'] = c['area']
            itme['toward'] = c['toward']
            itme['typ'] = c['type']
            itme['time'] = c['time']
            itme['rent'] = c['rent']
            itme['danw'] = c['danw']
            itme['region'] = a['region']
            itme['community'] = a['community']
            itme['title_names'] = i[0].strip()
            # 将封装好的数据都叫给管道进行保存
            yield itme
            print(itme)

        if self.count < 4:
            urls = self.url.format(self.count)
            print("现在是{}页".format(self.count))
            # 构建翻页请求
            urls_list = scrapy.Request(urls)
            # 将请求交给调度器入列
            yield urls_list
            self.count += 1