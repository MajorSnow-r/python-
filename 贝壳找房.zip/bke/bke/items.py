# Define here the models for your scraped items
#
# See documentation in:
# https://docs.scrapy.org/en/latest/topics/items.html

import scrapy


class BkeItem(scrapy.Item):
    # define the fields for your item here like:

    area = scrapy.Field()
    toward = scrapy.Field()
    typ = scrapy.Field()
    time = scrapy.Field()
    rent = scrapy.Field()
    danw = scrapy.Field()
    title_names = scrapy.Field()
    region = scrapy.Field()
    community = scrapy.Field()
    pass
