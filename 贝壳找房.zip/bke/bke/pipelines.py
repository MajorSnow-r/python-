# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html


# useful for handling different item types with a single interface
from itemadapter import ItemAdapter
import csv

class BkePipeline:
    # 程序开始的时候执行的代码
    def open_spider(self,spider):
        with open(file="bk.csv",mode="w",encoding="utf-8",newline="")as f:
            # 写入表头
            write = csv.DictWriter(f,fieldnames=["title_names","area","toward","typ","time","rent","danw","region","community"])
            write.writeheader()
    # 保存内容
    def process_item(self, item, spider):
        with open(file="bk.csv",mode="a",encoding="utf-8",newline="")as f:
            write = csv.DictWriter(f,fieldnames=["title_names","area","toward","typ","time","rent","danw","region","community"])
            write.writerow(item)
        return item
