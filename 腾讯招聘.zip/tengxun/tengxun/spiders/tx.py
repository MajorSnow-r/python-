import scrapy
from pprint import pprint
from tengxun.items import TengxunItem
"""
    1、腾讯招聘岗位名称
    2、腾讯招聘岗位简介
    3、保存数据库
    4、翻页爬取
"""

class TxSpider(scrapy.Spider):
    # 爬虫名称
    name = 'tx'
    # 爬取的范围
    allowed_domains = ['tencent.com']
    """因为这里面要翻页爬取数据,所以在初始化的url这边处理一下翻页的url
       1、通过分析找到了url翻页的规律 pageIndex=1 就是第一页
                                 pageIndex=2 就是第二页
       2、那么我们就可以通过循环去动态的处理这个翻页了 """

    url = "https://careers.tencent.com/tencentcareer/api/post/Query?timestamp=1665750692760&countryId=&cityId=&bgIds=&productId=&categoryId=40001001,40001002,40001003,40001004,40001005,40001006&parentCategoryId=&attrId=&keyword=&pageIndex={}&pageSize=10&language=zh-cn&area=cn"
    # 初始化的url
    start_urls = [url.format(1)]
    """以上url填好后,调度器会自动去给下载器进行下载,然后返回的就是下面函数中的 response文件"""

    def parse(self, response,**kwargs):
        # 因为返回的是json数据也就是字符串数据,所以可以直接用.json()将数据转成字典格式的,然后在用过里面的键或者get去取值
        json_dict = response.json()['Data']['Posts']
        """实例化一个items对象,用来封装数据"""
        item = TengxunItem()

        # ['Data']['Posts']一直取到剩下一个列表为止,然后在循环这个列表,在取数据
        for i in json_dict:
            item["tx_name"] = i['RecruitPostName']
            item["tx_texti"] = i['Responsibility']
            # 将数据通过yield传递给管道进行保存
            yield item
        pass

        """以上函数封装成解析数据的函数了,下面的方法是处理翻页的url"""
        for u in range(2,11):

            # 直接用self把上面第一个url调用过来,然后用字符串填错的方式,把动态数据填充进行
            list_url = self.url.format(u)

            # 构建请求,将构建的url给调度器入列
            chong_url = scrapy.Request(list_url)

            # 用yield将重构的url传给调度器入列
            yield chong_url

