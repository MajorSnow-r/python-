# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html


# useful for handling different item types with a single interface
from itemadapter import ItemAdapter
# 导入mongodb数据库
from pymongo import MongoClient

class TengxunPipeline:
    # 程序开始执行的函数,只会执行一次
    """ open_spider里面的spider参数就是爬虫程序对象,也就是spider==pntry """
    def open_spider(self,spider):
        #连接数据库
        mongo = MongoClient()
        # 切换数据库
        self.db = mongo.get_database("tengxun")
    def process_item(self, item, spider):
        # 写入数据倒数据库
        """这里面的itme是一个对象,要将这个对象转成字典格式的数据在写入"""
        # db = self.db.txzp.insert_one(dict(item))
        # print(db.inserted_id)
        bds = self.db.txzp.find({})
        for i in bds:
            print(i)
        # return 程序自带的
        return item

    def close_spider(self,spider):
        pass
