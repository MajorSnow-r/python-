# Define here the models for your scraped items
#
# See documentation in:
# https://docs.scrapy.org/en/latest/topics/items.html

import scrapy


class TengxunItem(scrapy.Item):
    # define the fields for your item here like:
    # 将数据都封装起来
    tx_name = scrapy.Field()
    tx_texti = scrapy.Field()
    pass
